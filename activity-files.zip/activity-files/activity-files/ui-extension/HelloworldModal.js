/*
 * <license header>
 */

import React, { useState, useEffect } from 'react'
import { attach } from "@adobe/uix-guest"
import {
  Flex,
  Form,
  ProgressCircle,
  Provider,
  Content,
  defaultTheme,
  Text,
  TextField,
  ButtonGroup,
  Button,
  Heading,
  View
} from '@adobe/react-spectrum'

import { extensionId } from "./Constants"

const branch = "main"                           //github.com branch name
const repo = "aem-ue"         //github.com repo name
const user = "yourOrg"                       //github.com username
const contentRoot = "/content/wknd-xwalk/" //Same as the root set in paths.json

export default function HelloworldModal() {
  // Fields
  const [guestConnection, setGuestConnection] = useState()
  const [editorState, setEditorState] = useState()
  const [previewUrl, setPreviewUrl] = useState(null)
  const [liveUrl, setLiveUrl] = useState(null)

  useEffect(() => {
    (async () => {
      try {
        const guestConnection = await attach({ id: extensionId })
        setGuestConnection(guestConnection)

        // Get the editor state: https://developer.adobe.com/uix/docs/services/aem-universal-editor/api/data/
        const editorState = await guestConnection.host.editorState.get();
        setEditorState(editorState)

        generateUrlsFromState(editorState)

      } catch (connectionError) {
        console.error("Could not establish guest connection:", connectionError.message);
      }
    })()
  }, [])

  // extracts the page path from the editor state and generates the preview and live URLs
  const generateUrlsFromState = (editorState) => {
    const location = editorState.location; //https://developer.adobe.com/uix/docs/services/aem-universal-editor/api/data/
    
    // Decode the URL since it may be URL-encoded (especially in stage/prod workspaces)
    const decodedLocation = decodeURIComponent(location);  
    const pagePath = decodedLocation.match(/\.com(\/content\/.*?)\.html/);

    if (!pagePath) {
      console.log("Could not extract page path from decoded location:", decodedLocation);
      return;
    }

    const pagePathWithoutRoot = pagePath[1].replace(contentRoot, ""); // Removes the root set from the paths.json
    console.log("Page path without root:", pagePathWithoutRoot);
    
    setPreviewUrl(`https://${branch}--${repo}--${user}.aem.page/${pagePathWithoutRoot}`);
    setLiveUrl(`https://${branch}--${repo}--${user}.aem.live/${pagePathWithoutRoot}`);
  }

  const onCloseHandler = () => {
    guestConnection.host.modal.close()
  }


  return (
    <Provider theme={defaultTheme} colorScheme='light'>
      <Content width="100%">
        <Flex direction="column" alignItems="center" justifyContent="center" gap="size-200" minHeight="100px">
          <ButtonGroup>
            <Button variant="primary">
              <a href={previewUrl} target="_blank" rel="noopener noreferrer" style={{ color: 'inherit', textDecoration: 'none' }}>
                PREVIEW
              </a>
            </Button>
            <Button variant="primary">
              <a href={liveUrl} target="_blank" rel="noopener noreferrer" style={{ color: 'inherit', textDecoration: 'none' }}>
                LIVE
              </a>
            </Button>
          </ButtonGroup>
        </Flex>
        <Flex direction="column" alignItems="end" justifyContent="center">
          <Button variant="secondary" onClick={onCloseHandler}>Close</Button>
        </Flex>
      </Content>
    </Provider>
  )
}
