curl -sSi -H --request POST \
  --url 'https://admin.hlx.page/cache/yourOrg/yourRepo/branch/*' \
  --header 'x-hlx-auth: your_personal_token_here'